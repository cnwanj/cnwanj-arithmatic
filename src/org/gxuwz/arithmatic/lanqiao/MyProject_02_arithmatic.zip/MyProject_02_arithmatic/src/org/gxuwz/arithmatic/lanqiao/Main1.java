package org.gxuwz.arithmatic.lanqiao;

import java.util.Arrays;

public class Main1 {

    private static int[] arr, arr1 = new int[5], arr2;
    private static int[] x = {-1, 1, -4, 4};
    private static int num = 0;

    public static void main(String[] args) {
        arr = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
        f(0, 0);
        System.out.println(num);
    }

    private static void f(int c, int p) {
        if (p == arr1.length) {
//            System.out.println(Arrays.toString(arr1));
            if (check()) {
                num ++;
            }
            return;
        }
        for (int i = c; i < arr.length; i++) {
            arr1[p] = arr[i];
            f(i + 1, p + 1);
        }
    }

    private static boolean check() {
        arr2 = new int[12];
        for (int i = 0; i < arr1.length; i++) {
            arr2[arr1[i] - 1] = 1;
        }
        boolean[] vis = new boolean[12];
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr2[i] == 1 && !vis[i]) {
                vis[i] = true;
                dfs(vis, i);
                count ++;
            }
        }
        if (count != 1 )
            return false;
        return true;
    }

    private static void dfs(boolean[] vis, int n) {
        for (int i = 0; i < x.length; i++) {
            int m = n + x[i];
            if (m >= 0 && m < arr.length && arr2[m] == 1 && !vis[m]) {
                if (i < 2) {
                    if (n / 4 == m / 4) {
                        vis[m] = true;
                        dfs(vis, m);
                    }
                } else {
                    vis[m] = true;
                    dfs(vis, m);
                }
            }
        }
    }
}


