package org.gxuwz.arithmatic.practice.t2;

import java.util.Vector;

/**
 * *** + *** = ***
 * 每个人*代表1~9的不同数字
 * 这个算数有多少种可能的正确填写方式
 */
public class Demo12 {
    public static void AllType(Vector<Character> source, Vector<Character> result) {
    }

    public static void main(String[] args) {
        Vector<Character> v = new Vector<>();
        v.elementAt(1);
        System.out.printf("%d+%d=%d", 1, 2, 3);
    }
}
